<button id="printarea" onclick="printData()" class="btn btn-outline-success">PRINT
    AREA</button>
<button class="btn btn-primary" onclick="ExportToExcel('xlsx')">EXPORT TO EXCEL</button>
<table id="table-dkp" class="table table-striped tabel-dkp table-responsive table-bordered">
    <thead>
        <tr>
            <th rowspan="2" style="text-align: center;">DIVISI</th>
            <th rowspan="2" style="text-align: center;">UNIT</th>
            <th rowspan="2">DK</th>
            <th rowspan="2">DSP</th>
            <th rowspan="2">DKP</th>
            <th rowspan="2">LIBUR</th>
            <th colspan="2">NS</th>
            <th colspan="3">SHIFT 1</th>
            <th colspan="3">SHIFT 2</th>
            <th colspan="3">SHIFT 3</th>
            <th colspan="3">GRAND TOTAL</th>
        </tr>
        <tr>
            <th>M</th>
            <th>TM</th>
            <th>M</th>
            <th>TM</th>
            <th>DKP</th>
            <th>M</th>
            <th>TM</th>
            <th>DKP</th>
            <th>M</th>
            <th>TM</th>
            <th>DKP</th>
            <th>M</th>
            <th>TM</th>
            <th>%</th>
        </tr>
    </thead>
    <?php $dkp2 = '0'; ?>
    <?php $dkpmnssl2 = '0'; ?>
    <?php $tmns12 = '0'; ?>
    <?php $dkpshs2 = '0'; ?>
    <?php $tmsh12 = '0'; ?>
    <?php $dkpshd2 = '0'; ?>
    <?php $tmsh22 = '0'; ?>
    <?php $dkpsht2 = '0'; ?>
    <?php $tmsh32 = '0'; ?>
    <?php $tmnsa2 = '0'; ?>
    <tbody>
        <?php foreach ($dkpharian as $dh => $value) : ?>
        <tr>
            <td><?= $dkpharian[$dh]['pembagian2_nama'] ?></td>
            <td><?= $dkpharian[$dh]['pembagian4_nama'] ?></td>
            <td><?= $dkp = $dkpharian[$dh]['dkp'] ?></td>
            <td></td>
            <td></td>
            <?php $dkp2 = $dkp2 + $dkp; ?>
            <td><?= $libur = $dkpharian[$dh]['sh0'] ?></td>
            <td><?= $dkpmnssl = $dkpmasuk[$dh]['ns1'] ?></td>
            <?php $dkpmnssl2 = $dkpmnssl2 + $dkpmnssl ?>
            <td><?= $tmns1 = $dkpharian[$dh]['ns1'] - $dkpmasuk[$dh]['ns1'] ?></td>
            <?php $tmns12 = $tmns12 + $tmns1; ?>
            <td><?= $dkpshs = $dkpmasuk[$dh]['sh1'] ?></td>
            <?php $dkpshs2 = $dkpshs2 + $dkpshs; ?>
            <td><?= $tmsh1 = $dkpharian[$dh]['sh1'] - $dkpmasuk[$dh]['sh1'] ?></td>
            <td style="font-weight: bold;"><?= $dkpharian[$dh]['sh1'] ?></td>
            <?php $tmsh12 = $tmsh12 + $tmsh1; ?>
            <td><?= $dkpshd = $dkpmasuk[$dh]['sh2'] ?></td>
            <?php $dkpshd2 = $dkpshd2 + $dkpshd ?>
            <td><?= $tmsh2 = $dkpharian[$dh]['sh2'] - $dkpmasuk[$dh]['sh2'] ?></td>
            <td style="font-weight: bold;"><?= $dkpharian[$dh]['sh2']  ?></td>
            <?php $tmsh22 = $tmsh22 + $tmsh2; ?>
            <td><?= $dkpsht = $dkpmasuk[$dh]['sh3'] ?></td>
            <?php $dkpsht2 = $dkpsht2 + $dkpsht ?>
            <td><?= $tmsh3 = $dkpharian[$dh]['sh3'] - $dkpmasuk[$dh]['sh3'] ?></td>
            <td style="font-weight: bold;"><?= $dkpharian[$dh]['sh3']  ?></td>
            <?php $tmsh32 = $tmsh32 + $tmsh3; ?>
            <td><?= $tmnsa = $dkpmnssl + $dkpshs + $dkpshd + $dkpsht ?></td>
            <td><?= $tmnsa = $tmns1 +  $tmsh1 + $tmsh2 + $tmsh3 ?></td>
            <?php $tmnsa2 = $tmnsa2 + $tmnsa  ?>
            <td><?= ceil((($tmns1 +  $tmsh1 + $tmsh2 + $tmsh3) / ($dkp - $libur)) * 100) ?>%</td>
        </tr>
        <?php endforeach ?>
        <tr>
            <td>TOTAL</td>
            <td></td>
            <td><?= $dkp2 ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td><?= $dkpmnssl2 ?></td>
            <td><?= $tmns12 ?></td>
            <td><?= $dkpshs2 ?></td>
            <td><?= $tmsh12 ?></td>
            <td></td>
            <td><?= $dkpshd2 ?></td>
            <td><?= $tmsh22 ?></td>
            <td></td>
            <td><?= $dkpsht2 ?></td>
            <td><?= $tmsh32 ?></td>
            <td></td>
            <td></td>
            <td><?= $tmnsa2 ?></td>
        </tr>
    </tbody>
    <!-- <tfoot>
    </tfoot> -->
</table>

<table id="tabel1" class="table table-striped table-bordered col-xl-12" style="width: 100%;">
    <div id="filtertable"></div>
    <thead>
        <tr>
            <th colspan="3">TIDAK FINGER</th>
        </tr>
        <tr>
            <th>NIP</th>
            <th>NAMA</th>
            <th>UNIT</th>
            <th>GRUP KERJA</th>
        </tr>
    </thead>
    <th>KARYAWAN NS</th>
    <tbody>
        <?php $n = 1; ?>
        <?php foreach ($stm as $sttm) : ?>
        <tr>
            <td><?= $sttm['nip'] ?></td>
            <td><?= $sttm['nama'] ?></td>
            <td><?= $sttm['unit'] ?></td>
            <td><?= $sttm['grup_jam_kerja'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
    <TH>KARYAWAN SHIFT 1</TH>
    <tbody>
        <?php $n = 1; ?>
        <?php foreach ($s1 as $s1) :
        ?>
        <tr>
            <td class="fix"><?= $s1['nip'] ?></td>
            <td><?= $s1['nama'] ?></td>
            <td><?= $s1['unit'] ?></td>
            <td><?= $s1['grup_jam_kerja'] ?></td>
        </tr>
        <?php
        endforeach ?>
    </tbody>
    <TH>KARYAWAN SHIFT 2</TH>
    <tbody>
        <?php $n = 1; ?>
        <?php foreach ($s2 as $s2) :
        ?>
        <tr>
            <td class="fix"><?= $s2['nip'] ?></td>
            <td><?= $s2['nama'] ?></td>
            <td><?= $s2['unit'] ?></td>
            <td><?= $s2['grup_jam_kerja'] ?></td>
        </tr>
        <?php
        endforeach ?>
    </tbody>
    <TH>KARYAWAN SHIFT 3</TH>
    <tbody>
        <?php $n = 1; ?>
        <?php foreach ($s3 as $s3) :
        ?>
        <tr>
            <td class="fix"><?= $s3['nip'] ?></td>
            <td><?= $s3['nama'] ?></td>
            <td><?= $s3['unit'] ?></td>
            <td><?= $s3['grup_jam_kerja'] ?></td>
        </tr>
        <?php
        endforeach ?>
    </tbody>
</table>


<table id="tabel1" class="table table-striped table-bordered" style="width: 100%;">
    <thead>
        <tr>
            <th colspan="3">TERLAMBAT</th>
        </tr>
        <tr>
            <th>NIP</th>
            <th>NAMA</th>
            <th>GRUP KERJA</th>
        </tr>
    </thead>
    <th>KARYAWAN NS</th>
    <tbody>
        <?php $n = 1; ?>
        <?php foreach ($tnss as $tnsa) :
        ?>
        <tr>
            <td class="fix"><?= $tnsa['pin'] ?></td>
            <td><?= $tnsa['nama'] ?></td>
            <td><?= $tnsa['selisih'] ?></td>
            <?php
        endforeach ?>
            <?php $n = 1; ?>
            <?php foreach ($tnsd as $tnssd) :
            ?>
            <td><?= $tnssd['pin'] ?></td>
            <td><?= $tnssd['nama'] ?></td>
            <td><?= $tnssd['selisih'] ?></td>
        </tr>
        <?php
            endforeach ?>
    </tbody>
</table>
<script type="text/javascript">
function ExportToExcel(type, fn, dl) {
    var elt = document.getElementById('table-dkp');
    var wb = XLSX.utils.table_to_book(elt, {
        sheet: "sheet1"
    });
    return dl ?
        XLSX.write(wb, {
            bookType: type,
            bookSST: true,
            type: 'base64'
        }) :
        XLSX.writeFile(wb, fn || ('MySheetName.' + (type || 'xlsx')));
}

function printData() {
    var divToPrint = document.getElementById('table-dkp');
    var htmlToPrint = '' +
        '<style type="text/css">' +
        'table th, table td {' +
        'border:1px solid #000;' +
        'padding:0.5em;' +
        '}' +
        '</style>';
    htmlToPrint += divToPrint.outerHTML;
    newWin = window.open("");
    newWin.document.write(htmlToPrint);
    newWin.print();
    newWin.close();
}
$('#addkaryawan').click(function(e) {
    $.ajax({
        url: "<?= site_url('admin/karyawanjp3a/add') ?>",
        type: "POST",
        dataType: "json",
        success: function(response) {
            if (response.sukses) {
                $('.vieweditdata').html(response.sukses).show();
                $('#tambahdata').modal('show');
            }
            $('input[name=csrf_test_name]').val(response.csrf_test_name);
        },
    });
});

function tabelunit(tgl) {
    $.ajax({
        url: "<?= site_url('admin/printrekap/rekapunit') ?>",
        type: "POST",
        data: {
            tglno: tgl
        },
        dataType: "json",
        success: function(response) {
            w = window.open(window.location.href, "_blank");
            w.document.open();
            w.document.write(response.sukses);
            w.document.close();
        },
        error: function(xhr, ajaxOption, thrownError) {
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
        }
    });
}
$(document).ready(function() {
    $("#list").change(function() {
        var idkar = $(this).val();

        $.ajax({
            url: '<?= site_url('admin/izin/datanamaform') ?>',
            type: 'post',
            data: {
                idkar: idkar
            },
            dataType: 'json',
            success: function(response) {
                $('.listtabelkaryawan').html(response.sukses);
            },
            error: function(xhr, ajaxOption, thrownError) {
                alert(xhr.status + "\n\n\n" + thrownError);
            }
        });
    });
});
$('#tabel1').DataTable({
    "responsive": true,
    "lengthMenu": [
        [5, 10, 20, 50],
        [5, 10, 20, 50]
    ],
    "initComplete": function() {
        this.api().columns([6, 3, 4]).every(function(d) { //THis is used for specific column
            var column = this;
            var theadname = $('#example3 th').eq([d]).text();
            var select = $('<select class="col col-3"> <option value = "" > ' + theadname +
                    ': All</option> </select > ')
                .appendTo('#filtertable')
                .on('change', function() {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search(val ? '^' + val + '$' : '', true, false)
                        .draw();
                });
            column.data().unique().sort().each(function(d, j) {
                var val = $(' <div/> ').html(d).text();
                select.append('<option value="' + d + '">' + d +
                    '</option>')
            });
        });
    },
    "buttons": ["copy", "csv", "colvis",
        {
            extend: 'excelHtml5',
            customize: function(xlsx) {
                var sheet = xlsx.xl.worksheets['sheet1.xml'];
                var col = $('col', sheet);
                col.each(function() {
                    $(this).attr('width', 9);
                });
            }
        },
        {
            'extend': 'pdfHtml5',
            'orientation': 'landscape',
            'pageSize': 'A1',
            'exportOptions': {
                'stripNewlines': false
            }
        },
        {
            'extend': 'print',
            'text': 'Print All',
            'orientation': 'landscape',
            'customize': function(win) {

                var last = null;
                var current = null;
                var bod = [];

                var css = '@page { size: landscape; }',
                    head = win.document.head || win.document.getElementsByTagName(
                        'head')[0],
                    style = win.document.createElement('style');

                style.type = 'text/css';
                style.media = 'print';

                if (style.styleSheet) {
                    style.styleSheet.cssText = css;
                } else {
                    style.appendChild(win.document.createTextNode(css));
                }

                head.appendChild(style);
            }
        },
        {
            extend: 'print',
            text: 'Print selected'
        }
    ],
    "order": [
        [3, "asc"],
        [1, "asc"]
    ],
    "dom": 'Bfrtip',
    "select": true,
    "paging": true,
    "lengthChange": false,
    "searching": true,
    "ordering": true,
    "info": true,
    "autoWidth": true,
    "scrollX": true,
    "fixedHeader": true
});
</script>